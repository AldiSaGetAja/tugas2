package com.latihan.tes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
